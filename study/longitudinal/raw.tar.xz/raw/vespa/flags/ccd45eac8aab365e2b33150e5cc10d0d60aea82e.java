// Copyright Vespa.ai. Licensed under the terms of the Apache 2.0 license. See LICENSE in the project root.
package com.yahoo.vespa.flags;

import com.yahoo.component.Vtag;
import com.yahoo.vespa.defaults.Defaults;
import com.yahoo.vespa.flags.custom.CustomerOtelExportParameters;
import com.yahoo.vespa.flags.custom.Sidecars;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.TreeMap;
import java.util.function.Predicate;

import static com.yahoo.vespa.flags.Dimension.APPLICATION;
import static com.yahoo.vespa.flags.Dimension.ARCHITECTURE;
import static com.yahoo.vespa.flags.Dimension.CLOUD_ACCOUNT;
import static com.yahoo.vespa.flags.Dimension.CLUSTER_ID;
import static com.yahoo.vespa.flags.Dimension.CLUSTER_TYPE;
import static com.yahoo.vespa.flags.Dimension.CONSOLE_USER_EMAIL;
import static com.yahoo.vespa.flags.Dimension.HOSTNAME;
import static com.yahoo.vespa.flags.Dimension.INSTANCE_ID;
import static com.yahoo.vespa.flags.Dimension.NODE_TYPE;
import static com.yahoo.vespa.flags.Dimension.TENANT_ID;
import static com.yahoo.vespa.flags.Dimension.VESPA_VERSION;

/**
 * Definitions of feature flags.
 *
 * <p>To use feature flags, define the flag in this class as an "unbound" flag, e.g. {@link UnboundBooleanFlag}
 * or {@link UnboundStringFlag}. At the location you want to get the value of the flag, you need the following:</p>
 *
 * <ol>
 *     <li>The unbound flag</li>
 *     <li>A {@link FlagSource}. The flag source is typically available as an injectable component. Binding
 *     an unbound flag to a flag source produces a (bound) flag, e.g. {@link BooleanFlag} and {@link StringFlag}.</li>
 *     <li>If you would like your flag value to be dependent on e.g. the application ID, then 1. you should
 *     declare this in the unbound flag definition in this file (referring to
 *     {@link Dimension#INSTANCE_ID}), and 2. specify the application ID when retrieving the value, e.g.
 *     {@link BooleanFlag#with(Dimension, String)}. See {@link FetchVector} for more info.</li>
 * </ol>
 *
 * <p>Once the code is in place, you can override the flag value. This depends on the flag source, but typically
 * there is a REST API for updating the flags in the config server, which is the root of all flag sources in the zone.</p>
 *
 * @author hakonhall
 */
public class Flags {

    private static volatile TreeMap<FlagId, FlagDefinition> flags = new TreeMap<>();

    public static final UnboundBooleanFlag GCP_ENCLAVE_V2 = defineFeatureFlag(
            "gcp-enclave-v2", false,
            List.of("hakonhall"), "2026-03-05", "2026-07-05",
            "Whether to enable v2 of Vespa Cloud Enclave in GCP",
            "Takes effect on the next host-admin tick.",
            CLOUD_ACCOUNT);

    public static final UnboundBooleanFlag USE_NON_PUBLIC_ENDPOINT_FOR_TEST = defineFeatureFlag(
            "use-non-public-endpoint-for-test", false,
            List.of("hakonhall"), "2025-03-19", "2026-07-10",
            "Whether to use non-public endpoint in test and staging environments (except Azure since it's not supported yet)",
            "Takes effect on next deployment of the application",
            INSTANCE_ID, VESPA_VERSION);

    public static final UnboundBooleanFlag LOCKED_GCP_PROVISION = defineFeatureFlag(
            "locked-gcp-provision", true,
            List.of("hakonhall"), "2025-08-05", "2026-07-15",
            "Whether to provision GCP hosts under the application- and unallocated- locks, even though it takes ~1m.",
            "Takes effect on next host being provisioned");

    public static final UnboundStringFlag RESPONSE_SEQUENCER_TYPE = defineStringFlag(
            "response-sequencer-type", "ADAPTIVE",
            List.of("hmusum"), "2020-12-02", "2026-06-01",
            "Selects type of sequenced executor used for mbus responses, valid values are LATENCY, ADAPTIVE, THROUGHPUT",
            "Takes effect at redeployment",
            INSTANCE_ID);

    public static final UnboundIntFlag RESPONSE_NUM_THREADS = defineIntFlag(
            "response-num-threads", 2,
            List.of("hmusum"), "2020-12-02", "2026-06-01",
            "Number of threads used for mbus responses, default is 2, negative number = numcores/4",
            "Takes effect at redeployment",
            INSTANCE_ID);

    public static final UnboundBooleanFlag USE_ASYNC_MESSAGE_HANDLING_ON_SCHEDULE = defineFeatureFlag(
            "async-message-handling-on-schedule", true,
            List.of("hmusum"), "2020-12-02", "2026-06-01",
            "Optionally deliver async messages in own thread",
            "Takes effect at redeployment",
            INSTANCE_ID);

    public static final UnboundIntFlag MBUS_JAVA_NUM_TARGETS = defineIntFlag(
            "mbus-java-num-targets", 2,
            List.of("hmusum"), "2022-07-05", "2026-06-01",
            "Number of rpc targets per service",
            "Takes effect at redeployment",
            INSTANCE_ID);
    public static final UnboundIntFlag MBUS_CPP_NUM_TARGETS = defineIntFlag(
            "mbus-cpp-num-targets", 2,
            List.of("hmusum"), "2022-07-05", "2026-06-01",
            "Number of rpc targets per service",
            "Takes effect at redeployment",
            INSTANCE_ID);
    public static final UnboundIntFlag RPC_NUM_TARGETS = defineIntFlag(
            "rpc-num-targets", 2,
            List.of("hmusum"), "2022-07-05", "2026-06-01",
            "Number of rpc targets per content node",
            "Takes effect at redeployment",
            INSTANCE_ID);
    public static final UnboundIntFlag MBUS_JAVA_EVENTS_BEFORE_WAKEUP = defineIntFlag(
            "mbus-java-events-before-wakeup", 1,
            List.of("hmusum"), "2022-07-05", "2026-06-01",
            "Number of write events before waking up transport thread",
            "Takes effect at redeployment",
            INSTANCE_ID);
    public static final UnboundIntFlag MBUS_CPP_EVENTS_BEFORE_WAKEUP = defineIntFlag(
            "mbus-cpp-events-before-wakeup", 1,
            List.of("hmusum"), "2022-07-05", "2026-06-01",
            "Number of write events before waking up transport thread",
            "Takes effect at redeployment",
            INSTANCE_ID);
    public static final UnboundIntFlag RPC_EVENTS_BEFORE_WAKEUP = defineIntFlag(
            "rpc-events-before-wakeup", 1,
            List.of("hmusum"), "2022-07-05", "2026-06-01",
            "Number of write events before waking up transport thread",
            "Takes effect at redeployment",
            INSTANCE_ID);

    public static final UnboundIntFlag MBUS_NUM_NETWORK_THREADS = defineIntFlag(
            "mbus-num-network-threads", 1,
            List.of("hmusum"), "2022-07-01", "2026-06-01",
            "Number of threads used for mbus network",
            "Takes effect at redeployment",
            INSTANCE_ID);

    public static final UnboundListFlag<String> ZONAL_WEIGHTED_ENDPOINT_RECORDS = defineListFlag(
            "zonal-weighted-endpoint-records", List.of(), String.class,
            List.of("hmusum"), "2023-12-15", "2026-06-01",
            "A list of weighted (application) endpoint fqdns for which we should use zonal endpoints as targets, not LBs.",
            "Takes effect at redeployment from controller");

    public static final UnboundListFlag<String> WEIGHTED_ENDPOINT_RECORD_TTL = defineListFlag(
            "weighted-endpoint-record-ttl", List.of(), String.class,
            List.of("hmusum"), "2023-05-16", "2026-06-01",
            "A list of endpoints and custom TTLs, on the form \"endpoint-fqdn:TTL-seconds\". " +
            "Where specified, CNAME records are used instead of the default ALIAS records, which have a default 60s TTL.",
            "Takes effect at redeployment from controller");

    public static final UnboundBooleanFlag WRITE_CONFIG_SERVER_SESSION_DATA_AS_ONE_BLOB = defineFeatureFlag(
            "write-config-server-session-data-as-blob", false,
            List.of("hmusum"), "2023-07-19", "2026-06-01",
            "Whether to write config server session data in one blob or as individual paths",
            "Takes effect immediately");

    public static final UnboundBooleanFlag READ_CONFIG_SERVER_SESSION_DATA_AS_ONE_BLOB = defineFeatureFlag(
            "read-config-server-session-data-as-blob", false,
            List.of("hmusum"), "2023-07-19", "2026-06-01",
            "Whether to read config server session data from session data blob or from individual paths",
            "Takes effect immediately");

    public static final UnboundDoubleFlag AUTOSCALER_TARGET_WRITE_CPU_PERCENTAGE = defineDoubleFlag(
            "autoscaler-target-write-cpu-percentage", 0.95,
            List.of("hmusum"), "2026-02-15", "2026-08-15",
            "Target write CPU percentage for autoscaler (e.g., 0.8 = 80%)",
            "Takes effect on next autoscaler evaluation",
            INSTANCE_ID, CLUSTER_ID);

    public static final UnboundBooleanFlag MORE_WIREGUARD = defineFeatureFlag(
            "more-wireguard", false,
            List.of("andreer"), "2023-08-21", "2026-06-01",
            "Use wireguard in INternal enCLAVES",
            "Takes effect on next host-admin run",
            HOSTNAME, CLOUD_ACCOUNT);

    public static final UnboundBooleanFlag IPV6_AWS_TARGET_GROUPS = defineFeatureFlag(
            "ipv6-aws-target-groups", false,
            List.of("andreer"), "2023-08-28", "2026-06-01",
            "Always use IPv6 target groups for load balancers in aws",
            "Takes effect on next load-balancer provisioning",
            HOSTNAME, CLOUD_ACCOUNT);

    public static final UnboundBooleanFlag PROVISION_IPV6_ONLY_AWS = defineFeatureFlag(
            "provision-ipv6-only", false,
            List.of("andreer"), "2023-08-28", "2026-06-01",
            "Provision without private IPv4 addresses in INternal enCLAVES in AWS",
            "Takes effect on next host provisioning / run of host-admin",
            HOSTNAME, CLOUD_ACCOUNT);

    public static final UnboundDoubleFlag DOCPROC_HANDLER_THREADPOOL = defineDoubleFlag(
            "docproc-handler-threadpool", 1.0,
            List.of("johsol"), "2025-10-17", "2026-06-01",
            "Adjust document processor handler threadpool size (scale the number of threads with cpu cores, 1 means same number of threads as cpu cores))",
            "Takes effect at redeployment",
            APPLICATION);

    public static final UnboundStringFlag ENDPOINT_CONFIG = defineStringFlag(
            "endpoint-config", "legacy",
            List.of("andreer", "olaa"), "2023-10-06", "2026-08-01",
            "Set the endpoint config to use for an application. Must be 'legacy', 'combined' or 'generated'. See EndpointConfig for further details",
            "Takes effect on next deployment through controller",
            TENANT_ID, APPLICATION, INSTANCE_ID);

    public static UnboundBooleanFlag LOGSERVER_OTELCOL_AGENT = defineFeatureFlag(
            "logserver-otelcol-agent", false,
            List.of("olaa"), "2024-04-03", "2026-08-01",
            "Whether logserver container should run otel agent",
            "Takes effect at redeployment",
            TENANT_ID, APPLICATION, INSTANCE_ID);

    public static final UnboundBooleanFlag USE_GRAFANA_ALLOY = defineFeatureFlag(
            "use-grafana-alloy", false,
            List.of("onur"), "2026-02-17", "2026-08-01",
            "Whether to use Grafana Alloy instead of otelcol-contrib for telemetry collection",
            "Takes effect on next host-admin tick",
            TENANT_ID, APPLICATION, INSTANCE_ID);

    public static final UnboundJacksonFlag<CustomerOtelExportParameters> CUSTOMER_OTEL_EXPORT = defineJacksonFlag(
            "customer-otel-export", new CustomerOtelExportParameters(null, null, null), CustomerOtelExportParameters.class,
            List.of("onur"), "2026-03-02", "2027-01-01",
            "Export telemetry to a customer-owned OTel endpoint in addition to the internal otel-gateway. " +
            "metrics and logs are independently optional. " +
            "logs.logFileNames is a list of log file enum names (e.g. CONTAINER_VESPA_LOGS, VAR_LOG_MESSAGES).",
            "Takes effect on next host-admin tick",
            __ -> true,
            TENANT_ID, APPLICATION, INSTANCE_ID);

    public static final UnboundBooleanFlag USE_LEGACY_WAND_QUERY_PARSING = defineFeatureFlag(
            "use-legacy-wand-query-parsing", true,
            List.of("arnej"), "2023-07-26", "2027-01-01",
            "If true, force legacy mode for weakAnd query parsing",
            "Takes effect at redeployment",
            INSTANCE_ID);

    public static final UnboundBooleanFlag USE_SIMPLE_ANNOTATIONS = defineFeatureFlag(
            "use-simple-annotations", true,
            List.of("arnej"), "2025-11-13", "2026-12-31",
            "Enable lightweight annotation representation for StringFieldValue",
            "Takes effect at redeployment",
            INSTANCE_ID);

    public static final UnboundBooleanFlag SNAPSHOTS_ENABLED = defineFeatureFlag(
            "snapshots-enabled", false,
            List.of("olaa"), "2024-10-22", "2026-08-01",
            "Whether node snapshots should be created when host storage is discarded",
            "Takes effect immediately");

    public static final UnboundBooleanFlag ENABLE_UI_VERSION_TOGGLE = defineFeatureFlag(
            "enable-ui-version-toggle", false,
            List.of("laura", "jille"), "2026-04-20", "2026-12-31",
            "Enable a toggle to switch between different versions of the Console UI",
            "Takes effect immediately",
            CONSOLE_USER_EMAIL);

    public static final UnboundBooleanFlag ENFORCE_EMAIL_DOMAIN_SSO = defineFeatureFlag(
            "enforce-email-domain-sso", false,
            List.of("eirik"), "2024-11-07", "2026-08-01",
            "Enforce SSO login for an email domain",
            "Takes effect immediately",
            CONSOLE_USER_EMAIL);

    public static final UnboundListFlag<String> RESTRICT_USERS_TO_DOMAIN = defineListFlag(
            "restrict-users-to-domain", List.of(), String.class,
            List.of("eirik"), "2024-11-07", "2026-08-01",
            "Only allow adding specific email domains as user to tenant",
            "Takes effect immediately",
            TENANT_ID);

    public static final UnboundJacksonFlag<Sidecars> SIDECARS_FOR_TEST = defineJacksonFlag(
            "sidecars-for-test", Sidecars.DEFAULT, Sidecars.class,
            List.of("glebashnik"), "2025-04-25", "2026-06-01",
            "Specifies configuration for sidecars to testing provisioning",
            "Takes effect at redeployment",
            __ -> true,
            APPLICATION
    );

    public static final UnboundBooleanFlag CREATE_TENANT_ROLES = defineFeatureFlag(
            "create-tenant-roles", true,
            List.of("andreer"), "2025-04-28", "2026-06-01",
            "Whether to create tenant specific roles",
            "Takes effect immediately",
            TENANT_ID
    );

    public static final UnboundBooleanFlag USE_TRITON = defineFeatureFlag(
            "use-triton", false,
            List.of("bjorncs", "glebashnik"), "2025-04-30", "2026-06-01",
            "Whether to use Triton as ONNX runtime",
            "Takes effect at redeployment",
            TENANT_ID, APPLICATION, INSTANCE_ID, CLUSTER_TYPE, CLUSTER_ID, VESPA_VERSION
    );

    public static final UnboundBooleanFlag DELETE_TENANT_ROLES = defineFeatureFlag(
            "delete-tenant-roles", false,
            List.of("andreer"), "2025-05-05", "2026-06-01",
            "Whether to delete tenant specific roles",
            "Role deletion happens when tenant is next processed by TenantRoleMaintainer",
            TENANT_ID
    );

    public static final UnboundIntFlag SEARCH_CORE_MAX_OUTSTANDING_MOVE_OPS = defineIntFlag(
            "search-core-max-outstanding-move-ops", 100,
            List.of("hmusum"), "2025-07-09", "2026-06-01",
            "The max outstanding move operations a maintenance job can have before being blocked.",
            "Takes effect at next deployment of the application",
            INSTANCE_ID);

    public static final UnboundBooleanFlag RESTART_ON_DEPLOY_MAINTAINER = defineFeatureFlag(
            "restart-on-deploy-maintainer", false,
            List.of("glebashnik"), "2026-04-07", "2026-10-07",
            "When enabled, RestartOnDeployMaintainer is used instead of PendingRestartsMaintainer " +
                    "to trigger pending restarts.",
            "Takes effect at next run of RestartOnDeployMaintainer and PendingRestartsMaintainer.",
            INSTANCE_ID
    );

    public static final UnboundBooleanFlag APPLY_ON_RESTART_FOR_APPLICATION_METADATA_CONFIG = defineFeatureFlag(
            "apply-on-restart-for-application-metadata-config", false,
            List.of("glebashnik"), "2026-02-13", "2026-08-13",
            "Whether to set applyOnRestart flag on ApplicationMetadataConfig. " +
                    "This might fix deferring config changes until container restart.",
            "Takes effect at redeployment",
            INSTANCE_ID
    );

    public static final UnboundIntFlag METRICS_PROXY_HEAP_SIZE_IN_MIB = defineIntFlag(
            "metrics-proxy-heap-size-in-mib", 0,
            List.of("hmusum"), "2026-04-29", "2026-06-01",
            "Amount of memory (in MiB) to use for metrics proxy JVM heap on non-admin nodes. 0 means use the default.",
            "Takes effect at redeployment",
            TENANT_ID, APPLICATION, INSTANCE_ID);

    public static final UnboundIntFlag METRICS_PROXY_ADMIN_HEAP_SIZE_IN_MIB = defineIntFlag(
            "metrics-proxy-admin-heap-size-in-mib", 0,
            List.of("hmusum"), "2026-04-29", "2026-06-01",
            "Amount of memory (in MiB) to use for metrics proxy JVM heap on admin nodes. 0 means use the default.",
            "Takes effect at redeployment",
            TENANT_ID, APPLICATION, INSTANCE_ID);

    public static final UnboundBooleanFlag SKIP_AUTOSCALING_WHEN_UPGRADING_CONFIG_SERVERS = defineFeatureFlag(
            "skip-autoscaling-when-upgrading-config-servers", false,
            List.of("hmusum"), "2026-05-05", "2026-06-05",
            "Whether to skip autoscaling when config server upgrades or downgrades.",
            "Takes effect immediately",
            HOSTNAME);
    public static final UnboundBooleanFlag SEND_OLD_QUERY_STACK = defineFeatureFlag(
            "send-old-query-stack", false,
            List.of("arnej"), "2026-05-07", "2026-09-01",
            "If true, send the old query stack format in addition to protobuf serialization.",
            "Takes effect at redeployment",
            TENANT_ID, APPLICATION, INSTANCE_ID);


    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static UnboundBooleanFlag defineFeatureFlag(String flagId, boolean defaultValue, List<String> owners,
                                                       String createdAt, String expiresAt, String description,
                                                       String modificationEffect, Dimension... dimensions) {
        return define(UnboundBooleanFlag::new, flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static UnboundStringFlag defineStringFlag(String flagId, String defaultValue, List<String> owners,
                                                     String createdAt, String expiresAt, String description,
                                                     String modificationEffect, Dimension... dimensions) {
        return defineStringFlag(flagId, defaultValue, owners,
                                createdAt, expiresAt, description,
                                modificationEffect, value -> true,
                                dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static UnboundStringFlag defineStringFlag(String flagId, String defaultValue, List<String> owners,
                                                     String createdAt, String expiresAt, String description,
                                                     String modificationEffect, Predicate<String> validator,
                                                     Dimension... dimensions) {
        return define((i, d, v) -> new UnboundStringFlag(i, d, v, validator),
                      flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static UnboundIntFlag defineIntFlag(String flagId, int defaultValue, List<String> owners,
                                               String createdAt, String expiresAt, String description,
                                               String modificationEffect, Dimension... dimensions) {
        return define(UnboundIntFlag::new, flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static UnboundLongFlag defineLongFlag(String flagId, long defaultValue, List<String> owners,
                                                 String createdAt, String expiresAt, String description,
                                                 String modificationEffect, Dimension... dimensions) {
        return define(UnboundLongFlag::new, flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static UnboundDoubleFlag defineDoubleFlag(String flagId, double defaultValue, List<String> owners,
                                                     String createdAt, String expiresAt, String description,
                                                     String modificationEffect, Dimension... dimensions) {
        return define(UnboundDoubleFlag::new, flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static <T> UnboundJacksonFlag<T> defineJacksonFlag(String flagId, T defaultValue, Class<T> jacksonClass, List<String> owners,
                                                              String createdAt, String expiresAt, String description,
                                                              String modificationEffect, Predicate<T> validator, Dimension... dimensions) {
        return define((id2, defaultValue2, vector2) -> new UnboundJacksonFlag<>(id2, defaultValue2, vector2, jacksonClass, validator),
                      flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static <T> UnboundListFlag<T> defineListFlag(String flagId, List<T> defaultValue, Class<T> elementClass,
                                                        List<String> owners, String createdAt, String expiresAt,
                                                        String description, String modificationEffect, Dimension... dimensions) {
        return define((fid, dval, fvec) -> new UnboundListFlag<>(fid, dval, elementClass, fvec),
                flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    /** WARNING: public for testing: All flags should be defined in {@link Flags}. */
    public static <T> UnboundListFlag<T> defineListFlag(String flagId, List<T> defaultValue, Class<T> elementClass,
                                                        List<String> owners, String createdAt, String expiresAt,
                                                        String description, String modificationEffect,
                                                        Predicate<List<T>> validator, Dimension... dimensions) {
        return define((fid, dval, fvec) -> new UnboundListFlag<>(fid, dval, elementClass, fvec, validator),
                flagId, defaultValue, owners, createdAt, expiresAt, description, modificationEffect, dimensions);
    }

    @FunctionalInterface
    private interface TypedUnboundFlagFactory<T, U extends UnboundFlag<?, ?, ?>> {
        U create(FlagId id, T defaultValue, FetchVector defaultFetchVector);
    }

    /**
     * Defines a Flag.
     *
     * @param factory            Factory for creating unbound flag of type U
     * @param flagId             The globally unique FlagId.
     * @param defaultValue       The default value if none is present after resolution.
     * @param description        Description of how the flag is used.
     * @param modificationEffect What is required for the flag to take effect? A restart of process? immediately? etc.
     * @param dimensions         What dimensions will be set in the {@link FetchVector} when fetching
     *                           the flag value in
     *                           {@link FlagSource#fetch(FlagId, FetchVector) FlagSource::fetch}.
     *                           For instance, if APPLICATION is one of the dimensions here, you should make sure
     *                           APPLICATION is set to the ApplicationId in the fetch vector when fetching the RawFlag
     *                           from the FlagSource.
     *                           SYSTEM, CLOUD, ENVIRONMENT, and ZONE_ID are special:  These dimensions are resolved just
     *                           before the flag data is published to a zone.  This means there is never any need to set
     *                           these dimensions when resolving a flag, and setting these dimensions just before resolving
     *                           the flag will have no effect.
     *                           There is one exception.  If any of these dimensions are declared when defining a flag,
     *                           then those dimensions are NOT resolved when published to the controllers.  This allows
     *                           the controller to resolve the flag to different values based on which cloud or zone
     *                           it is operating on.  Flags should NOT declare these dimensions unless they intend to
     *                           use them in the controller in this way.
     * @param <T>                The boxed type of the flag value, e.g. Boolean for flags guarding features.
     * @param <U>                The type of the unbound flag, e.g. UnboundBooleanFlag.
     * @return An unbound flag with {@link Dimension#HOSTNAME HOSTNAME} and
     *         {@link Dimension#VESPA_VERSION VESPA_VERSION} already set. The ZONE environment
     *         is typically implicit.
     */
    private static <T, U extends UnboundFlag<?, ?, ?>> U define(TypedUnboundFlagFactory<T, U> factory,
                                                                String flagId,
                                                                T defaultValue,
                                                                List<String> owners,
                                                                String createdAt,
                                                                String expiresAt,
                                                                String description,
                                                                String modificationEffect,
                                                                Dimension[] dimensions) {
        FlagId id = new FlagId(flagId);
        FetchVector vector = new FetchVector()
                .with(HOSTNAME, Defaults.getDefaults().vespaHostname())
                // Warning: In unit tests and outside official Vespa releases, the currentVersion is e.g. 7.0.0
                // (determined by the current major version). Consider not setting VESPA_VERSION if minor = micro = 0.
                .with(VESPA_VERSION, Vtag.currentVersion.toFullString());
        U unboundFlag = factory.create(id, defaultValue, vector);
        FlagDefinition definition = new FlagDefinition(
                unboundFlag, owners, parseDate(createdAt), parseDate(expiresAt), description, modificationEffect, dimensions);
        if (flags.put(id, definition) != null)
            throw new IllegalStateException("There are multiple definitions of the " + id + " flag");
        return unboundFlag;
    }

    private static Instant parseDate(String rawDate) {
        return DateTimeFormatter.ISO_DATE.parse(rawDate, LocalDate::from).atStartOfDay().toInstant(ZoneOffset.UTC);
    }

    public static List<FlagDefinition> getAllFlags() {
        return List.copyOf(flags.values());
    }

    public static Optional<FlagDefinition> getFlag(FlagId flagId) {
        return Optional.ofNullable(flags.get(flagId));
    }

    /**
     * Allows the statically defined flags to be controlled in a test.
     *
     * <p>Returns a Replacer instance to be used with e.g. a try-with-resources block. Within the block,
     * the flags starts out as cleared. Flags can be defined, etc. When leaving the block, the flags from
     * before the block is reinserted.
     *
     * <p>NOT thread-safe. Tests using this cannot run in parallel.
     */
    public static Replacer clearFlagsForTesting(FlagId... flagsToKeep) {
        return new Replacer(flagsToKeep);
    }

    public static class Replacer implements AutoCloseable {
        private static volatile boolean flagsCleared = false;

        private final TreeMap<FlagId, FlagDefinition> savedFlags;

        private Replacer(FlagId... flagsToKeep) {
            verifyAndSetFlagsCleared(true);
            this.savedFlags = Flags.flags;
            Flags.flags = new TreeMap<>();
            List.of(flagsToKeep).forEach(id -> Flags.flags.put(id, savedFlags.get(id)));
        }

        @Override
        public void close() {
            verifyAndSetFlagsCleared(false);
            Flags.flags = savedFlags;
        }

        /**
         * Used to implement a simple verification that Replacer is not used by multiple threads.
         * For instance two different tests running in parallel cannot both use Replacer.
         */
        private static void verifyAndSetFlagsCleared(boolean newValue) {
            if (flagsCleared == newValue) {
                throw new IllegalStateException("clearFlagsForTesting called while already cleared - running tests in parallell!?");
            }
            flagsCleared = newValue;
        }
    }
}
